package com.example.servicecrm.dto;

import com.example.servicecrm.domain.LocalDateTimeAdapter;
import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlRootElement;
import jakarta.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import java.time.LocalDateTime;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class ConsultaAgendamentoDTO {

    private Integer pacienteId;
    private Integer medicoId;

    @XmlJavaTypeAdapter(LocalDateTimeAdapter.class)
    private LocalDateTime dataHora;

    private String motivo;

    public ConsultaAgendamentoDTO() {
    }

    public ConsultaAgendamentoDTO(Integer pacienteId, Integer medicoId, LocalDateTime dataHora, String motivo) {
        this.pacienteId = pacienteId;
        this.medicoId = medicoId;
        this.dataHora = dataHora;
        this.motivo = motivo;
    }

    public Integer getPacienteId() {
        return pacienteId;
    }

    public void setPacienteId(Integer pacienteId) {
        this.pacienteId = pacienteId;
    }

    public Integer getMedicoId() {
        return medicoId;
    }

    public void setMedicoId(Integer medicoId) {
        this.medicoId = medicoId;
    }

    public LocalDateTime getDataHora() {
        return dataHora;
    }

    public void setDataHora(LocalDateTime dataHora) {
        this.dataHora = dataHora;
    }

    public String getMotivo() {
        return motivo;
    }

    public void setMotivo(String motivo) {
        this.motivo = motivo;
    }

    @Override
    public String toString() {
        return "ConsultaAgendamentoDTO{" +
                "pacienteId=" + pacienteId +
                ", medicoId=" + medicoId +
                ", dataHora=" + dataHora +
                ", motivo='" + motivo + '\'' +
                '}';
    }
}
