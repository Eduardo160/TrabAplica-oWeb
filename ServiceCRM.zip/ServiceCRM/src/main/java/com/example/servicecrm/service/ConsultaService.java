package com.example.servicecrm.service;

import com.example.servicecrm.domain.Consulta;
import com.example.servicecrm.domain.Medico;
import com.example.servicecrm.domain.Paciente;
import com.example.servicecrm.dto.ConsultaAgendamentoDTO;
import com.example.servicecrm.dto.ConsultaCancelamentoDTO;
import com.example.servicecrm.exceptions.BusinessException;
import com.example.servicecrm.repositories.ConsultaRepository;
import com.example.servicecrm.repositories.MedicoRepository;
import com.example.servicecrm.repositories.PacienteRepository;

import javax.naming.NamingException;
import java.sql.SQLException;
import java.time.DayOfWeek;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.Random;

public class ConsultaService {

    private final ConsultaRepository consultaRepository;
    private final MedicoRepository medicoRepository;
    private final PacienteRepository pacienteRepository;

    public ConsultaService() {
        this.consultaRepository = new ConsultaRepository();
        this.medicoRepository = new MedicoRepository();
        this.pacienteRepository = new PacienteRepository();
    }

    public void agendar(ConsultaAgendamentoDTO dto) throws BusinessException {
        LocalDateTime dataHora = dto.getDataHora();

        if (dataHora == null) {
            throw new BusinessException("Data e hora da consulta são obrigatórias.");
        }

        if (dataHora.isBefore(LocalDateTime.now().plusMinutes(30))) {
            throw new BusinessException("A consulta deve ser agendada com no mínimo 30 minutos de antecedência.");
        }

        DayOfWeek diaSemana = dataHora.getDayOfWeek();
        int hora = dataHora.getHour();

        if (diaSemana == DayOfWeek.SUNDAY) {
            throw new BusinessException("A clínica não funciona aos domingos.");
        }

        if (hora < 7 || hora >= 19) {
            throw new BusinessException("A consulta deve ser entre 07:00 e 19:00.");
        }

        try {
            Paciente paciente = pacienteRepository.buscarPorId(dto.getPacienteId().longValue());

            if (paciente == null || !Boolean.TRUE.equals(paciente.getAtivo())) {
                throw new BusinessException("Paciente inativo ou inexistente.");
            }

            if (consultaRepository.pacienteJaTemConsultaNoDia(dto.getPacienteId().longValue(), dataHora.toLocalDate())) {
                throw new BusinessException("Paciente já possui consulta no dia.");
            }

            Integer medicoId = dto.getMedicoId();

            if (medicoId != null) {
                Medico medico = medicoRepository.buscarPorId(medicoId);
                if (medico == null || !medico.isAtivo()) {
                    throw new BusinessException("Médico inativo ou inexistente.");
                }

                if (consultaRepository.medicoOcupado(dataHora, medicoId.longValue())) {
                    throw new BusinessException("Médico já possui consulta agendada nesse horário.");
                }
            } else {
                List<Medico> disponiveis = medicoRepository.buscarDisponiveis(dataHora);
                if (disponiveis == null || disponiveis.isEmpty()) {
                    throw new BusinessException("Nenhum médico disponível nesse horário.");
                }
                Medico selecionado = disponiveis.get(new Random().nextInt(disponiveis.size()));
                medicoId = selecionado.getId();
            }

            Consulta consulta = new Consulta(
                    dto.getPacienteId().longValue(),
                    medicoId.longValue(),
                    dataHora,
                    dto.getMotivo(),
                    "Agendada"
            );

            consultaRepository.agendar(consulta);

        } catch (SQLException | NamingException e) {
            throw new BusinessException("Erro no processo de agendamento: " + e.getMessage());
        } catch (Exception e) {
            throw new BusinessException("Erro inesperado: " + e.getMessage());
        }
    }


    public void cancelar(ConsultaCancelamentoDTO dto) throws BusinessException {
        if (dto.getMotivoCancelamento() == null || dto.getMotivoCancelamento().isBlank()) {
            throw new BusinessException("Motivo do cancelamento é obrigatório.");
        }

        String motivo = dto.getMotivoCancelamento().toLowerCase();
        if (!motivo.equals("paciente desistiu") && !motivo.equals("médico cancelou") && !motivo.equals("outros")) {
            throw new BusinessException("Motivo do cancelamento deve ser: paciente desistiu, médico cancelou ou outros.");
        }

        Consulta consulta;
        try {
            consulta = consultaRepository.buscarPorId(dto.getId());
        } catch (Exception e) {
            throw new BusinessException("Erro ao buscar consulta: " + e.getMessage());
        }

        if (consulta == null) {
            throw new BusinessException("Consulta não encontrada.");
        }

        LocalDateTime agora = LocalDateTime.now();
        if (consulta.getDataHora().isBefore(agora.plusHours(24))) {
            throw new BusinessException("Só é possível cancelar uma consulta com no mínimo 24 horas de antecedência.");
        }

        consulta.setStatus("Cancelada");
        consulta.setMotivo(dto.getMotivoCancelamento());

        try {
            consultaRepository.atualizar(consulta);
        } catch (Exception e) {
            throw new BusinessException("Erro ao cancelar consulta: " + e.getMessage());
        }
    }
}
