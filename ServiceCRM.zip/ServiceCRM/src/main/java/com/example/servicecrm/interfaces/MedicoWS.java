package com.example.servicecrm.interfaces;

import com.example.servicecrm.domain.Medico;
import com.example.servicecrm.domain.Paciente;
import com.example.servicecrm.dto.MedicoInsertRequestDTO;
import com.example.servicecrm.dto.MedicoUpdateRequestDTO;
import com.example.servicecrm.exceptions.BusinessException;
import jakarta.jws.WebMethod;
import jakarta.jws.WebParam;
import jakarta.jws.WebService;

import java.util.List;

@WebService
public interface MedicoWS {

    @WebMethod
    Medico inserir(MedicoInsertRequestDTO medico) throws BusinessException;

    @WebMethod
    Medico editar(Medico medico) throws BusinessException;

    @WebMethod
    List<Medico> buscarTodos() throws BusinessException;

    @WebMethod
    void excluir(@WebParam(name="id") Integer id) throws BusinessException;

    @WebMethod
    List<Medico> buscarPorNome(@WebParam(name="nome") String nome) throws BusinessException;
}

