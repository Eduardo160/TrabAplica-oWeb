package com.example.servicecrm;

import com.example.servicecrm.dto.ConsultaAgendamentoDTO;
import com.example.servicecrm.dto.ConsultaCancelamentoDTO;
import com.example.servicecrm.interfaces.ConsultaWS;
import com.example.servicecrm.service.ConsultaService;
import jakarta.jws.WebService;

@WebService(endpointInterface = "com.example.servicecrm.interfaces.ConsultaWS")
public class ConsultaWSImpl implements ConsultaWS {

    private final ConsultaService service = new ConsultaService();

    @Override
    public void agendarConsulta(ConsultaAgendamentoDTO dto) throws Exception {
        service.agendar(dto);
    }

    @Override
    public void cancelarConsulta(ConsultaCancelamentoDTO dto) throws Exception {
        service.cancelar(dto);
    }
}
