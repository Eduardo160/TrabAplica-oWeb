package com.example.servicecrm;

import com.example.servicecrm.domain.Paciente;
import com.example.servicecrm.dto.PacienteInsertRequestDTO;
import com.example.servicecrm.exceptions.BusinessException;
import com.example.servicecrm.interfaces.PacienteWS;
import com.example.servicecrm.service.PacienteService;
import jakarta.jws.WebMethod;
import jakarta.jws.WebParam;
import jakarta.jws.WebService;

import java.util.List;

@WebService(endpointInterface = "com.example.servicecrm.interfaces.PacienteWS")
public class PacienteWSImpl implements PacienteWS {

    private final PacienteService service = new PacienteService();

    @Override
    public void inserir(PacienteInsertRequestDTO dto) throws BusinessException {
        service.inserir(dto);
    }

    @Override
    public void editar(Paciente paciente) throws BusinessException {
        service.editar(paciente);
    }

    @Override
    @WebMethod
    public void inativar(@WebParam (name="cpf") String cpf) throws BusinessException {
        service.inativar(cpf);
    }

    @Override
    public List<Paciente> listarTodos() throws Exception {
        return service.listarTodos();
    }
}