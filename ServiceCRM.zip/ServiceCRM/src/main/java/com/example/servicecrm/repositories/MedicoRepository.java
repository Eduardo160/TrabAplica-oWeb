package com.example.servicecrm.repositories;

import com.example.servicecrm.domain.Medico;
import com.example.servicecrm.infrastructure.ConnectionFactory;

import javax.naming.NamingException;
import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class MedicoRepository {

    private static final String INSERT =
            "INSERT INTO medico (nome, email, telefone, crm, especialidade, logradouro, numero, complemento, bairro, ativo) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    private static final String UPDATE =
            "UPDATE medico SET nome = ?, telefone = ?, logradouro = ?, numero = ?, complemento = ?, bairro = ?, ativo = ? WHERE id = ?";

    private static final String FIND_ALL = "SELECT * FROM medico";

    private static final String FIND_ALL_ACTIVE_ORDERED =
            "SELECT * FROM medico WHERE ativo = true ORDER BY nome ASC";

    private static final String FIND_BY_NOME =
            "SELECT * FROM medico WHERE nome ILIKE ?";

    private static final String DELETE_BY_ID =
            "DELETE FROM medico WHERE id = ?";

    private static final String FIND_BY_ID =
            "SELECT * FROM medico WHERE id = ?";

    private static final String BUSCAR_DISPONIVEIS =
            "SELECT * FROM medico WHERE ativo = true AND id NOT IN (\n" +
                    "    SELECT medico_id FROM consulta WHERE data_hora = ? AND status = 'Agendada'\n" +
                    ")";

    public Medico inserir(Medico medico) throws SQLException, NamingException {
        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(INSERT, Statement.RETURN_GENERATED_KEYS)) {

            preencherInsert(pstmt, medico);
            pstmt.executeUpdate();

            try (ResultSet rs = pstmt.getGeneratedKeys()) {
                if (rs.next()) {
                    medico.setId(rs.getInt(1));
                }
            }
        }
        return medico;
    }

    public Medico atualizar(Medico medico) throws SQLException, NamingException {
        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(UPDATE)) {

            preencherUpdate(pstmt, medico);
            pstmt.setInt(8, medico.getId());
            pstmt.executeUpdate();
        }
        return medico;
    }

    public List<Medico> buscarTodos() throws SQLException, NamingException {
        return buscarMedicos(FIND_ALL);
    }

    public List<Medico> buscarTodosAtivosOrdenadosPorNome() throws SQLException, NamingException {
        return buscarMedicos(FIND_ALL_ACTIVE_ORDERED);
    }

    public Medico buscarPorId(Integer id) throws SQLException, NamingException {
        String sql = "SELECT * FROM medico WHERE id = ? AND ativo = true";

        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, id); // usa setInt, não setLong
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    Medico medico = new Medico();
                    medico.setId(rs.getInt("id"));
                    medico.setNome(rs.getString("nome"));
                    medico.setEmail(rs.getString("email"));
                    medico.setTelefone(rs.getString("telefone"));
                    medico.setCrm(rs.getString("crm"));
                    medico.setEspecialidade(rs.getString("especialidade"));
                    medico.setLogradouro(rs.getString("logradouro"));
                    medico.setNumero(rs.getString("numero"));
                    medico.setComplemento(rs.getString("complemento"));
                    medico.setBairro(rs.getString("bairro"));
                    medico.setAtivo(rs.getBoolean("ativo"));
                    return medico;
                } else {
                    return null;
                }
            }
        }
    }

    public List<Medico> buscarPorNome(String nome) throws SQLException, NamingException {
        List<Medico> medicos = new ArrayList<>();

        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(FIND_BY_NOME)) {

            pstmt.setString(1, "%" + nome + "%");

            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    medicos.add(criarMedico(rs));
                }
            }
        }
        return medicos;
    }

    public void deletar(Integer id) throws SQLException, NamingException {
        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(DELETE_BY_ID)) {

            pstmt.setInt(1, id);
            pstmt.executeUpdate();
        }
    }

    public boolean existsByEmail(String email) throws SQLException, NamingException {
        return existsBy("email", email);
    }

    public boolean existsByCrm(String crm) throws SQLException, NamingException {
        return existsBy("crm", crm);
    }

    private boolean existsBy(String fieldName, String value) throws SQLException, NamingException {
        if (!fieldName.equals("email") && !fieldName.equals("crm")) {
            throw new IllegalArgumentException("Campo não permitido para verificação: " + fieldName);
        }

        String query = "SELECT COUNT(*) FROM medico WHERE " + fieldName + " = ?";

        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, value);
            try (ResultSet rs = pstmt.executeQuery()) {
                return rs.next() && rs.getInt(1) > 0;
            }
        }
    }

    private List<Medico> buscarMedicos(String query) throws SQLException, NamingException {
        List<Medico> medicos = new ArrayList<>();

        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                medicos.add(criarMedico(rs));
            }
        }

        return medicos;
    }

    public List<Medico> buscarDisponiveis(LocalDateTime dataHora) throws SQLException, NamingException {
        List<Medico> medicos = new ArrayList<>();

        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(BUSCAR_DISPONIVEIS)) {

            pstmt.setTimestamp(1, Timestamp.valueOf(dataHora));

            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    medicos.add(criarMedico(rs));
                }
            }
        }

        return medicos;
    }

    private void preencherInsert(PreparedStatement pstmt, Medico medico) throws SQLException {
        pstmt.setString(1, medico.getNome());
        pstmt.setString(2, medico.getEmail());
        pstmt.setString(3, medico.getTelefone());
        pstmt.setString(4, medico.getCrm());
        pstmt.setString(5, medico.getEspecialidade());
        pstmt.setString(6, medico.getLogradouro());
        pstmt.setString(7, medico.getNumero());
        pstmt.setString(8, medico.getComplemento());
        pstmt.setString(9, medico.getBairro());
        pstmt.setBoolean(10, medico.isAtivo());
    }

    private void preencherUpdate(PreparedStatement pstmt, Medico medico) throws SQLException {
        pstmt.setString(1, medico.getNome());
        pstmt.setString(2, medico.getTelefone());
        pstmt.setString(3, medico.getLogradouro());
        pstmt.setString(4, medico.getNumero());
        pstmt.setString(5, medico.getComplemento());
        pstmt.setString(6, medico.getBairro());
        pstmt.setBoolean(7, medico.isAtivo());
    }

    private Medico criarMedico(ResultSet rs) throws SQLException {
        Medico medico = new Medico();
        medico.setId(rs.getInt("id"));
        medico.setNome(rs.getString("nome"));
        medico.setEmail(rs.getString("email"));
        medico.setTelefone(rs.getString("telefone"));
        medico.setCrm(rs.getString("crm"));
        medico.setEspecialidade(rs.getString("especialidade"));
        medico.setLogradouro(rs.getString("logradouro"));
        medico.setNumero(rs.getString("numero"));
        medico.setComplemento(rs.getString("complemento"));
        medico.setBairro(rs.getString("bairro"));
        medico.setAtivo(rs.getBoolean("ativo"));
        return medico;
    }
}