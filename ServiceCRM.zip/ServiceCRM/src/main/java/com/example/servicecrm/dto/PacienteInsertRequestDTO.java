package com.example.servicecrm.dto;

public class PacienteInsertRequestDTO {
    public String nome;
    public String email;
    public String cpf;
    public String telefone;
    public String endereco;
}