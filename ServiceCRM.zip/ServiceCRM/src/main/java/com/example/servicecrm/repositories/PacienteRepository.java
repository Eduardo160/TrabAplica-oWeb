package com.example.servicecrm.repositories;

import com.example.servicecrm.domain.Paciente;
import com.example.servicecrm.exceptions.BusinessException;
import com.example.servicecrm.infrastructure.ConnectionFactory;
import javax.naming.NamingException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PacienteRepository {

    private static final String INSERT =
            "INSERT INTO paciente (nome, email, cpf, telefone, endereco, ativo) VALUES (?, ?, ?, ?, ?, ?)";

    private static final String UPDATE =
            "UPDATE paciente SET nome = ?, telefone = ?, endereco = ? WHERE cpf = ?";

    private static final String INATIVAR =
            "UPDATE paciente SET ativo = false WHERE cpf = ?";

    private static final String FIND_ALL_ATIVOS =
            "SELECT * FROM paciente WHERE ativo = true ORDER BY nome ASC";

    public void inserir(Paciente paciente) throws BusinessException {
        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(INSERT)) {

            stmt.setString(1, paciente.getNome());
            stmt.setString(2, paciente.getEmail());
            stmt.setString(3, paciente.getCpf());
            stmt.setString(4, paciente.getTelefone());
            stmt.setString(5, paciente.getEndereco());
            stmt.setBoolean(6, paciente.getAtivo());

            stmt.executeUpdate();
        } catch (Exception e) {
            throw new BusinessException("Erro ao inserir paciente: " + e.getMessage());
        }
    }

    public void editar(Paciente paciente) throws BusinessException {
        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(UPDATE)) {

            stmt.setString(1, paciente.getNome());
            stmt.setString(2, paciente.getTelefone());
            stmt.setString(3, paciente.getEndereco());
            stmt.setString(4, paciente.getCpf());

            stmt.executeUpdate();
        } catch (Exception e) {
            throw new BusinessException("Erro ao editar paciente: " + e.getMessage());
        }
    }

    public void atualizar(Paciente paciente) throws BusinessException {
        editar(paciente);
    }

    public void inativar(String cpf) throws BusinessException {
        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(INATIVAR)) {

            stmt.setString(1, cpf);
            int rows = stmt.executeUpdate();

            if (rows == 0) {
                throw new BusinessException("Nenhum paciente encontrado com o CPF: " + cpf);
            }

        } catch (Exception e) {
            throw new BusinessException("Erro ao inativar paciente: " + e.getMessage());
        }
    }

    public List<Paciente> buscarTodos() throws BusinessException {
        List<Paciente> pacientes = new ArrayList<>();

        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(FIND_ALL_ATIVOS);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Paciente paciente = new Paciente();
                paciente.setId(rs.getInt("id"));
                paciente.setNome(rs.getString("nome"));
                paciente.setEmail(rs.getString("email"));
                paciente.setCpf(rs.getString("cpf"));
                paciente.setTelefone(rs.getString("telefone"));
                paciente.setEndereco(rs.getString("endereco"));
                paciente.setAtivo(rs.getBoolean("ativo"));
                pacientes.add(paciente);
            }
        } catch (Exception e) {
            throw new BusinessException("Erro ao buscar pacientes: " + e.getMessage());
        }

        return pacientes;
    }

    public Paciente buscarPorCpf(String cpf) {
        Paciente paciente = null;
        String sql = "SELECT * FROM paciente WHERE cpf = ? AND ativo = true";

        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, cpf);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                paciente = new Paciente();
                paciente.setId(rs.getInt("id"));
                paciente.setNome(rs.getString("nome"));
                paciente.setEmail(rs.getString("email"));
                paciente.setCpf(rs.getString("cpf"));
                paciente.setTelefone(rs.getString("telefone"));
                paciente.setEndereco(rs.getString("endereco"));
                paciente.setAtivo(rs.getBoolean("ativo"));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } catch (NamingException e) {
            e.printStackTrace();
        }

        return paciente;
    }

    public Paciente buscarPorId(Long id) {
        Paciente paciente = null;
        String sql = "SELECT * FROM paciente WHERE id = ? AND ativo = true";

        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setLong(1, id);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                paciente = new Paciente();
                paciente.setId(rs.getInt("id"));
                paciente.setNome(rs.getString("nome"));
                paciente.setEmail(rs.getString("email"));
                paciente.setCpf(rs.getString("cpf"));
                paciente.setTelefone(rs.getString("telefone"));
                paciente.setEndereco(rs.getString("endereco"));
                paciente.setAtivo(rs.getBoolean("ativo"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (NamingException e) {
            e.printStackTrace();
        }
        return paciente;
    }

    public List<Paciente> listarTodos() throws BusinessException {
        return buscarTodos();
    }
}
