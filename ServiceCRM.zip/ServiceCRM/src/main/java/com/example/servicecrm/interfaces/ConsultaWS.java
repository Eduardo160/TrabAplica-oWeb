package com.example.servicecrm.interfaces;

import com.example.servicecrm.dto.ConsultaAgendamentoDTO;
import com.example.servicecrm.dto.ConsultaCancelamentoDTO;
import jakarta.jws.WebMethod;
import jakarta.jws.WebService;

@WebService
public interface ConsultaWS {

    @WebMethod
    void agendarConsulta(ConsultaAgendamentoDTO dto) throws Exception;

    @WebMethod
    void cancelarConsulta(ConsultaCancelamentoDTO dto) throws Exception;
}
