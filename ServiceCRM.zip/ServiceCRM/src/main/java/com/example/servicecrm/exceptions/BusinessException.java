package com.example.servicecrm.exceptions;

import jakarta.xml.ws.WebFault;

@WebFault(name = "BusinessFault", targetNamespace = "http://interfaces.servicecrm./")
public class BusinessException extends Exception {

    private static final long serialVersionUID = 1L;

    private final String faultInfo;

    public BusinessException(String message) {
        super(message);
        this.faultInfo = message;
    }

    public BusinessException(String message, Throwable cause) {
        super(message, cause);
        this.faultInfo = message;
    }

    public String getFaultInfo() {
        return faultInfo;
    }
}
