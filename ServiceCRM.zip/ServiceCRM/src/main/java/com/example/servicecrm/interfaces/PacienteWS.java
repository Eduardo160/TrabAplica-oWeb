package com.example.servicecrm.interfaces;

import com.example.servicecrm.domain.Paciente;
import com.example.servicecrm.dto.PacienteInsertRequestDTO;
import com.example.servicecrm.exceptions.BusinessException;
import jakarta.jws.WebMethod;
import jakarta.jws.WebParam;
import jakarta.jws.WebService;

import java.util.List;

@WebService
public interface PacienteWS {

    @WebMethod
    void inserir(PacienteInsertRequestDTO dto) throws BusinessException;

    @WebMethod
    void editar(Paciente paciente) throws BusinessException;

    @WebMethod
    void inativar(@WebParam(name="cpf") String cpf) throws BusinessException;

    @WebMethod
    List<Paciente> listarTodos() throws Exception;
}