package com.example.servicecrm.dto;

public class PacienteUpdateRequestDTO {
    public String cpf;
    public String nome;
    public String telefone;
    public String endereco;
}