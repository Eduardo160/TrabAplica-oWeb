package com.example.servicecrm;

import com.example.servicecrm.domain.Medico;
import com.example.servicecrm.domain.Paciente;
import com.example.servicecrm.dto.MedicoInsertRequestDTO;
import com.example.servicecrm.dto.MedicoUpdateRequestDTO;
import com.example.servicecrm.exceptions.BusinessException;
import com.example.servicecrm.interfaces.MedicoWS;
import com.example.servicecrm.repositories.MedicoRepository;
import com.example.servicecrm.service.MedicoService;
import com.example.servicecrm.service.PacienteService;
import jakarta.jws.WebMethod;
import jakarta.jws.WebParam;
import jakarta.jws.WebService;

import javax.naming.NamingException;
import java.sql.SQLException;
import java.util.List;

@WebService(endpointInterface = "com.example.servicecrm.interfaces.MedicoWS")
public class MedicoWSImp implements MedicoWS {

    private final MedicoService medicoService;
    private final MedicoRepository medicoRepository = new MedicoRepository();

    public MedicoWSImp() {
        this.medicoService = new MedicoService();
    }

    @Override
    public Medico inserir(MedicoInsertRequestDTO medicoDTO) throws BusinessException {
        Medico medico = new Medico(medicoDTO);
        return medicoService.inserir(medico);
    }

    @Override
    public Medico editar(Medico medico) throws BusinessException {
        return medicoService.editar(medico);
    }

    @Override
    public List<Medico> buscarTodos() throws BusinessException {
        return medicoService.buscarTodos();
    }

    @Override
    @WebMethod
    public void excluir(@WebParam (name="id") Integer id) throws BusinessException {
        medicoService.excluir(id);
    }

    @Override
    @WebMethod
    public List<Medico> buscarPorNome(@WebParam(name="nome") String nome) throws BusinessException {
        return medicoService.buscarPorNome(nome);
    }

    @WebMethod
    public Medico cadastrarMedico(MedicoInsertRequestDTO medicoDTO) throws SQLException, NamingException {
        Medico medico = new Medico(medicoDTO);
        return medicoRepository.inserir(medico);
    }

    @WebMethod
    public Medico editarMedico(Medico medico) throws SQLException, NamingException {
        medicoRepository.atualizar(medico);
        return medico;
    }

    @WebMethod
    public List<Medico> listarMedicos() throws SQLException, NamingException {
        return medicoRepository.buscarTodos();
    }

    @WebMethod
    public boolean deletarMedico(Integer id) throws SQLException, NamingException {
        medicoRepository.deletar(id);
        return true;
    }

    @WebMethod
    public Medico buscarMedicoPorId(Integer id) throws SQLException, NamingException {
        return medicoRepository.buscarPorId(id);
    }
}
