package com.example.servicecrm.service;

import com.example.servicecrm.domain.Medico;
import com.example.servicecrm.dto.MedicoUpdateRequestDTO;
import com.example.servicecrm.exceptions.BusinessException;
import com.example.servicecrm.repositories.MedicoRepository;
import jakarta.jws.WebParam;
import javax.naming.NamingException;
import java.sql.SQLException;
import java.util.List;

public class MedicoService {

    private final MedicoRepository medicoRepository;

    public MedicoService() {
        this.medicoRepository = new MedicoRepository();
    }

    public Medico inserir(Medico medico) throws BusinessException {
        try {
            if (medicoRepository.existsByEmail(medico.getEmail())) {
                throw new BusinessException("Já existe um médico cadastrado com esse e-mail.");
            }

            if (medicoRepository.existsByCrm(medico.getCrm())) {
                throw new BusinessException("Já existe um médico cadastrado com esse CRM.");
            }

            return medicoRepository.inserir(medico);
        } catch (SQLException | NamingException e) {
            throw new BusinessException("Erro ao inserir médico: " + e.getMessage());
        }
    }

    public Medico atualizar(MedicoUpdateRequestDTO dto) throws BusinessException {
        Medico medico;
        try {
            medico = medicoRepository.buscarPorId(dto.getId()); // Retorna Medico direto
        } catch (SQLException | NamingException e) {
            throw new BusinessException("Erro ao buscar médico para atualização: " + e.getMessage());
        }

        if (medico == null) {
            throw new BusinessException("Médico não encontrado para o ID informado.");
        }

        medico.setNome(dto.getNome());
        medico.setTelefone(dto.getTelefone());
        medico.setLogradouro(dto.getLogradouro());
        medico.setNumero(dto.getNumero());
        medico.setComplemento(dto.getComplemento());
        medico.setBairro(dto.getBairro());

        try {
            return medicoRepository.atualizar(medico);
        } catch (SQLException | NamingException e) {
            throw new BusinessException("Erro ao atualizar médico: " + e.getMessage());
        }
    }

    public List<Medico> buscarTodos() throws BusinessException {
        try {
            return medicoRepository.buscarTodos();
        } catch (SQLException | NamingException e) {
            throw new BusinessException("Erro ao buscar médicos: " + e.getMessage());
        }
    }

    public void excluir(@WebParam(name = "id") Integer id) throws BusinessException {
        Medico medico;
        try {
            medico = medicoRepository.buscarPorId(id); // Retorna Medico direto
        } catch (SQLException | NamingException e) {
            throw new BusinessException("Erro ao buscar médico para exclusão: " + e.getMessage());
        }

        if (medico == null) {
            throw new BusinessException("Médico não encontrado.");
        }

        medico.setAtivo(false);
        try {
            medicoRepository.atualizar(medico);
        } catch (SQLException | NamingException e) {
            throw new BusinessException("Erro ao excluir médico: " + e.getMessage());
        }
    }

    public List<Medico> buscarPorNome(String nome) throws BusinessException {
        try {
            return medicoRepository.buscarPorNome(nome);
        } catch (SQLException | NamingException e) {
            throw new BusinessException("Erro ao buscar médicos por nome: " + e.getMessage());
        }
    }

    public List<Medico> listarTodosAtivos() throws BusinessException {
        try {
            return medicoRepository.buscarTodosAtivosOrdenadosPorNome();
        } catch (SQLException | NamingException e) {
            throw new BusinessException("Erro ao listar médicos ativos: " + e.getMessage());
        }
    }

    public Medico editar(Medico medicoEditado) throws BusinessException {
        if (medicoEditado.getId() == null) {
            throw new BusinessException("ID do médico é obrigatório para edição.");
        }

        // Busca o médico original no banco de dados
        Medico medicoOriginal = null;
        try {
            medicoOriginal = medicoRepository.buscarPorId(medicoEditado.getId());
        } catch (SQLException | NamingException e) {
            throw new BusinessException("Erro ao buscar médico para edição: " + e.getMessage());
        }

        if (medicoOriginal == null || !medicoOriginal.isAtivo()) {
            throw new BusinessException("Médico inexistente ou inativo.");
        }

        // Validações de campos que NÃO podem ser alterados
        if (!medicoEditado.getEmail().equals(medicoOriginal.getEmail())) {
            throw new BusinessException("Não é permitido alterar o e-mail do médico.");
        }

        if (!medicoEditado.getCrm().equals(medicoOriginal.getCrm())) {
            throw new BusinessException("Não é permitido alterar o CRM do médico.");
        }

        if (!medicoEditado.getEspecialidade().equals(medicoOriginal.getEspecialidade())) {
            throw new BusinessException("Não é permitido alterar a especialidade do médico.");
        }

        // Atualiza os campos permitidos
        medicoOriginal.setNome(medicoEditado.getNome());
        medicoOriginal.setTelefone(medicoEditado.getTelefone());
        medicoOriginal.setLogradouro(medicoEditado.getLogradouro());
        medicoOriginal.setNumero(medicoEditado.getNumero());
        medicoOriginal.setComplemento(medicoEditado.getComplemento());
        medicoOriginal.setBairro(medicoEditado.getBairro());

        // Atualiza no banco
        try {
            medicoRepository.atualizar(medicoOriginal);
        } catch (SQLException | NamingException e) {
            throw new BusinessException("Erro ao atualizar médico: " + e.getMessage());
        }

        return medicoOriginal;
    }
}
