package com.example.servicecrm.repositories;

import com.example.servicecrm.domain.Consulta;
import com.example.servicecrm.infrastructure.ConnectionFactory;

import javax.naming.NamingException;
import java.sql.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class ConsultaRepository {

    private static final String AGENDAR =
            "INSERT INTO consulta (paciente_id, medico_id, data_hora, motivo, status) VALUES (?, ?, ?, ?, ?)";

    private static final String CANCELAR =
            "UPDATE consulta SET status = 'Cancelada', motivo = ? WHERE id = ?";

    private static final String VERIFICAR_CONSULTA_PACIENTE_DIA =
            "SELECT COUNT(*) FROM consulta WHERE paciente_id = ? AND DATE(data_hora) = ? AND status = 'Agendada'";

    private static final String VERIFICAR_MEDICO_OCUPADO =
            "SELECT COUNT(*) FROM consulta WHERE medico_id = ? AND data_hora = ? AND status = 'Agendada'";

    public void agendar(Consulta consulta) throws SQLException, NamingException {
        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(AGENDAR)) {
            pstmt.setLong(1, consulta.getPacienteId());
            pstmt.setLong(2, consulta.getMedicoId());
            pstmt.setTimestamp(3, Timestamp.valueOf(consulta.getDataHora()));
            pstmt.setString(4, consulta.getMotivo());
            pstmt.setString(5, consulta.getStatus());
            pstmt.executeUpdate();
        }
    }

    public boolean pacienteJaTemConsultaNoDia(Long pacienteId, LocalDate data) throws SQLException, NamingException {
        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(VERIFICAR_CONSULTA_PACIENTE_DIA)) {
            pstmt.setLong(1, pacienteId);
            pstmt.setDate(2, Date.valueOf(data));
            try (ResultSet rs = pstmt.executeQuery()) {
                return rs.next() && rs.getInt(1) > 0;
            }
        }
    }

    public boolean medicoOcupado(LocalDateTime dataHora, Long medicoId) throws SQLException, NamingException {
        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(VERIFICAR_MEDICO_OCUPADO)) {
            pstmt.setLong(1, medicoId);
            pstmt.setTimestamp(2, Timestamp.valueOf(dataHora));
            try (ResultSet rs = pstmt.executeQuery()) {
                return rs.next() && rs.getInt(1) > 0;
            }
        }
    }

    public Consulta buscarPorId(Integer id) throws SQLException, NamingException {
        String sql = "SELECT * FROM consulta WHERE id = ?";

        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setLong(1, id.longValue());

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    Consulta consulta = new Consulta();
                    consulta.setId(rs.getLong("id"));
                    consulta.setPacienteId(rs.getLong("paciente_id"));
                    consulta.setMedicoId(rs.getLong("medico_id"));
                    consulta.setDataHora(rs.getTimestamp("data_hora").toLocalDateTime());
                    consulta.setMotivo(rs.getString("motivo"));
                    consulta.setStatus(rs.getString("status"));
                    return consulta;
                }
            }
        }

        return null;
    }

    public void atualizar(Consulta consulta) throws SQLException, NamingException {
        String sql = "UPDATE consulta SET status = ?, motivo = ? WHERE id = ?";

        try (Connection conn = ConnectionFactory.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, consulta.getStatus());
            stmt.setString(2, consulta.getMotivo());
            stmt.setLong(3, consulta.getId());

            stmt.executeUpdate();
        }
    }


}