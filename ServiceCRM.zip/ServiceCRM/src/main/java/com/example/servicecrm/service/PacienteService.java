package com.example.servicecrm.service;

import com.example.servicecrm.domain.Paciente;
import com.example.servicecrm.dto.PacienteInsertRequestDTO;
import com.example.servicecrm.dto.PacienteUpdateRequestDTO;
import com.example.servicecrm.exceptions.BusinessException;
import com.example.servicecrm.repositories.PacienteRepository;
import jakarta.jws.WebParam;

import java.util.List;

public class PacienteService {

    private final PacienteRepository repository;

    public PacienteService() {
        this.repository = new PacienteRepository();
    }

    public void inserir(PacienteInsertRequestDTO dto) throws BusinessException {
        try {
            Paciente paciente = new Paciente(dto.nome, dto.email, dto.cpf, dto.telefone, dto.endereco);
            repository.inserir(paciente);
        } catch (Exception e) {
            throw new BusinessException("Erro ao inserir paciente: " + e.getMessage());
        }
    }

    public List<Paciente> buscarTodos() throws BusinessException {
        try {
            return repository.buscarTodos();
        } catch (Exception e) {
            throw new BusinessException("Erro ao buscar pacientes: " + e.getMessage());
        }
    }

    public void editar(Paciente paciente) throws BusinessException {
        try {
            repository.editar(paciente);
        } catch (Exception e) {
            throw new BusinessException("Erro ao editar paciente: " + e.getMessage());
        }
    }

    public void inativar(@WebParam(name = "cpf") String cpf) throws BusinessException {
        try {
            repository.inativar(cpf);
        } catch (Exception e) {
            throw new BusinessException("Erro ao inativar paciente: " + e.getMessage());
        }
    }

    public List<Paciente> listarTodos() throws BusinessException {
        try {
            return repository.listarTodos();
        } catch (Exception e) {
            throw new BusinessException("Erro ao listar pacientes: " + e.getMessage());
        }
    }

    public Paciente atualizar(PacienteUpdateRequestDTO dto) throws BusinessException {
        try {
            Paciente existente = repository.buscarPorCpf(dto.cpf);
            if (existente == null) {
                throw new BusinessException("Paciente não encontrado para o CPF: " + dto.cpf);
            }

            existente.setNome(dto.nome);
            existente.setTelefone(dto.telefone);
            existente.setEndereco(dto.endereco);

            repository.atualizar(existente);
            return existente;
        } catch (Exception e) {
            throw new BusinessException("Erro ao atualizar paciente: " + e.getMessage());
        }
    }
}
